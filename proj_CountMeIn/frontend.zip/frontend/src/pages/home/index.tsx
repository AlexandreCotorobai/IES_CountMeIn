import React from "react";
import { ModeToggle } from "@/components/ModeToggle";
import { Button } from "@/components/ui/button"

export function Component() {
    return (
        <>  
            <div>
            </div>
        </>
    )
}

