import React from "react";



export function Component() {
    return (
        <div>
            <h1>Login</h1>
        </div>
    )
}

